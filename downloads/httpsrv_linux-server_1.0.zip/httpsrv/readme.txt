﻿Links:
------
WebPage: http://www.leemann.se/fredrik
Donate: https://www.paypal.me/freddan88

YouTube: https://www.youtube.com/user/FreLee54

Tutorial Debian: http://www.leemann.se/fredrik/tutorials/project-httpsrv-v1-deb-based-linux
Tutorial CentOS: http://www.leemann.se/fredrik/tutorials/project-httpsrv-v1-rpm-based-linux

Httpsrv Video Debian: https://www.youtube.com/watch?v=d-o8Kckeb_o&t=1s
Httpsrv Video CentOS: https://www.youtube.com/watch?v=0dim9_-_mAg&t=1s

Description:
------------
Easy to use script to compile and install Apache2 and PHP7 from Source
This script will also help you manage the service, stare/stop/restart etc.

I take no responsibility for this script, use at your own risk
Security and bugs shall be reported to apache php or mysql
This script is only tested with softwareversions found in httpsrv.sh
The script is only tested with: CentOS, Debian and Ubuntu 16.04 Linux

-----------------------------------------------------------------------------