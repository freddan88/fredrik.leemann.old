﻿Author: Fredrik Leemann

Links:
------
WebPage: http://www.leemann.se/fredrik
Donate: https://www.paypal.me/freddan88
YouTube: https://www.youtube.com/user/FreLee54
GitHub: https://github.com/freddan88

OpenTFTPD By: achaldhir
https://sourceforge.net/projects/tftp-server/files/?source=navbar

Description:
------------
Files to be used for imaging and OEM installation on Xubuntu Linux

Tested in Xubuntu 16.04

I take no responsibility for this script, use at your own risk

--------------------------------------------------------------
More to come!!!