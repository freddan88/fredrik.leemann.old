#!/bin/bash
if [ "$(id -u)" != "0" ]; then 
	echo "This script needs to be executed as sudo" 
	echo " " && exit; fi
#### Remove software:
	apt-get remove pidgin simple-scan transmission-gtk avahi* -y
	apt-get purge parole openssh-server -y && apt-get autoremove -y

### Install Software:
	add-apt-repository ppa:numix/ppa -y && apt-get update
	apt-get install numix-icon-theme-circle numix-wallpaper* gksu -y
	
#### Create backups:
	mv /etc/default/grub /etc/default/grub.bak
	mv /etc/lightdm/lightdm-gtk-greeter.conf /etc/lightdm/lightdm-gtk-greeter.bak
	rm /etc/xdg/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml
	
#### Copy files and generate grub.cfg:
	cp -R /usr/oem/files/skel /etc/
	cp /usr/oem/scripts/bin/* /usr/bin/
	cp /usr/oem/scripts/local/bin/* /usr/local/bin/
	cp /usr/oem/scripts/local/sbin/* /usr/local/sbin/
	cp /usr/oem/applications/* /usr/share/applications/
	cp /usr/oem/files/99-no-guest.conf /usr/share/lightdm/lightdm.conf.d/99-no-guest.conf
	cp /usr/oem/files/lightdm-gtk-greeter.conf /etc/lightdm/lightdm-gtk-greeter.conf
	cp /usr/oem/files/xfce4-notifyd.xml /etc/xdg/xfce4/xfconf/xfce-perchannel-xml
	cp /usr/oem/files/xsettings.xml /etc/xdg/xfce4/xfconf/xfce-perchannel-xml
	cp /usr/oem/files/xfwm4.xml /etc/xdg/xfce4/xfconf/xfce-perchannel-xml
	cp -R /usr/oem/files/tftpsrv /srv/tftpsrv 
	cp /usr/oem/files/grub /etc/default/grub
	grub-mkconfig -o /boot/grub/grub.cfg

#### Change permissions:
	chmod 755 /usr/share/applications/debian-update.desktop
	chmod 755 /usr/bin/upgrade-apt.sh
	chmod -R 775 /srv/tftpsrv
	chmod 777 /srv/tftpsrv/log
	chmod 664 /srv/tftpsrv/doc/*
	chmod 755 /usr/local/sbin/*
	chmod 755 /usr/local/bin/*
	
#### The contents of this script:
	echo ""
	echo "----------------------------"
	echo "The contents of this script: " && sleep 1
	cat /usr/oem/oem.sh
######################################
	
## Delete folder: /usr/oem
rm -rf /usr/oem