#!/bin/bash
if [ "$(id -u)" != "0" ]; then 
	echo "This script needs to be executed as sudo" 
	echo " " && exit; fi
#####################################################################
	echo "Installing software and finalizing installation" && sleep 1
	apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys BBEBDCB318AD50EC6865090613B00F1FD2C19886
	echo deb http://repository.spotify.com stable non-free | sudo tee /etc/apt/sources.list.d/spotify.list
	add-apt-repository ppa:webupd8team/brackets -y && apt-get update
	apt-get install brackets spotify-client frozen-bubble openarena supertux hedgewars quadrapassel gnome-nibbles xmoto -y
	apt-get install gnome-system-monitor gnome-disk-utility gparted vlc gksu gimp openshot vokoscreen audacity -y
	grub-mkconfig -o /boot/grub/grub.cfg
	# other software: kazam clementine
	echo ""
	echo "----------------------------"
	echo "The contents of this script: "
	echo ""
	rm -rf /media/oem 2>/dev/null && sleep 1
	cat /usr/local/sbin/finalize.sh
	echo ""
###################################
rm /usr/local/sbin/finalize.sh