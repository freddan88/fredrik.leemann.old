
Download initrd.img and vmlinuz from:
http://ftp.ember.se/centos/6.9/os/x86_64/images/pxeboot

OBS! ftp.ember.se is a Swedish ftp
You may want to use a server in your country

List of mirrors:
http://isoredirect.centos.org/centos/6/isos/x86_64/

--


