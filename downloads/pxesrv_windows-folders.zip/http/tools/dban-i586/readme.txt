
Download Darik's Boot and Nuke (DBAN) as iso

Link:
https://sourceforge.net/projects/dban/files/dban/dban-2.3.0/dban-2.3.0_i586.iso/download

--