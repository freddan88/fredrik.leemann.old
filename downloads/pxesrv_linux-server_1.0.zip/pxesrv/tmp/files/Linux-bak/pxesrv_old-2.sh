#!/bin/sh
# Please do not edit bellow!
##########
Group=sudo
User=www-data
ServerRoot=/srv/pxesrv
SourceDir=/srv/pxesrv/src
PidPath=/srv/pxesrv/src/pid
PxeBoot=/srv/pxesrv/pxe-boot
LogDir=/srv/pxesrv/share/log
BuildDir=/srv/pxesrv/src/build
##############################
if [ "$(id -u)" != "0" ]; then
	echo " "
	echo "PLEASE RUN THIS SCRIPT AS ROOT OR SUDO!"
	echo "---------------------------------------"
	exit
fi

case $1 in

restart)
echo " "
	echo "Stopping services"
	echo "-----------------"
	$0 stop >/dev/null
	$0 run
;;

status)
echo " "
	if ! [ -f $PidPath/pxesrv.lock ]; then
		echo "Services is not running"
		echo "-----------------------"
	else
		echo "Pidfiles located in: $PidPath"
		echo " " && echo "Displaying processes runing:"
		echo " "
		echo "  PID TTY          TIME CMD"	
		ps -e | grep $(cat $PidPath/dnsmasq.pid) 2>/dev/null
		ps -e | grep $(cat $PidPath/lighttpd.pid) 2>/dev/null
	fi
echo " "
;;

stop)
echo " "
	if ! [ -f $PidPath/dnsmasq.pid ]; then
		echo "Dnsmasq is not running"
	else
		echo "Stopping Dnsmasq" && sleep 1
		kill -9 $(cat $PidPath/dnsmasq.pid) 2>/dev/null
		rm -f $PidPath/dnsmasq.pid 2>/dev/null
	fi

	if ! [ -f $PidPath/lighttpd.pid ]; then
		echo "Lighttpd is not running"
	else
		echo "Stopping Lighttpd" && sleep 1
		kill -9 $(cat $PidPath/lighttpd.pid) 2>/dev/null
		rm -f $PidPath/lighttpd.pid 2>/dev/null
	fi

	rm -f $PidPath/pxesrv.lock
echo " "
;;

start)
echo " "
	kill -9 $(cat $PidPath/dnsmasq.pid) 2>/dev/null
	kill -9 $(cat $PidPath/lighttpd.pid) 2>/dev/null
	rm -f $PidPath/pxesrv.lock 2>/dev/null
	rm -f $PidPath/*.pid 2>/dev/null
	$ServerRoot/sbin/lighttpd -f $ServerRoot/conf/lighttpd.conf
	$ServerRoot/sbin/dnsmasq -x $PidPath/dnsmasq.pid --conf-file=$ServerRoot/conf/dnsmasq.conf
	touch $PidPath/pxesrv.lock
	echo "Starting services for pxesrv - lighttpd + dnsmasq"
echo " "
;;

run)
echo " "
	if [ -f $PidPath/pxesrv.lock ]; then
		echo "Services is running"
		echo "-------------------"
	else
		echo "Starting Lighttpd - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/lighttpd -f $ServerRoot/conf/lighttpd.conf
		ps -e | grep $(cat $PidPath/lighttpd.pid) 2>/dev/null
		echo " "
		echo "Starting Dnsmasq - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/dnsmasq -x $PidPath/dnsmasq.pid --conf-file=$ServerRoot/conf/dnsmasq.conf
		ps -e | grep $(cat $PidPath/dnsmasq.pid) 2>/dev/null
		touch $PidPath/pxesrv.lock
	fi
echo " "
;;

install_dnsmasq)
	kill -9 $(cat $PidPath/dnsmasq.pid) 2>/dev/null
	kill -9 $(cat $PidPath/lighttpd.pid) 2>/dev/null
	rm -f $PidPath/pxesrv.lock 2>/dev/null
	rm -f $PidPath/*.pid 2>/dev/null
	echo " "
	if [ -f $ServerRoot/sbin/dnsmasq ]; then
		echo "Service dnsmasq used by pxesrv is installed"
		echo "-------------------------------------------" && exit
	fi

	if [ -f $SourceDir/dnsmasq*.tar.gz ]; then
		cd $SourceDir && tar zvxf dnsmasq*.tar.gz -C $BuildDir && cd $BuildDir/dnsmasq*
		sed -i 's/usr/srv/g' Makefile
		sed -i 's/local/pxesrv/g' Makefile		
		sed -i 's/pxesrve/locale/g' Makefile
		make && make install
		echo "Entering directory: $ServerRoot"
		cd $ServerRoot && mkdir -p $PxeBoot
		sleep 1 && rm -rf $BuildDir/dnsmasq*
	else
		echo "Sourcearchive (tar.gz) Not installed in $SourceDir/dnsmasq"
		echo "----------------------------------------------------------"	
	fi
echo " "
;;

install_lighttpd)
	kill -9 $(cat $PidPath/dnsmasq.pid) 2>/dev/null
	kill -9 $(cat $PidPath/lighttpd.pid) 2>/dev/null
	rm -f $PidPath/pxesrv.lock 2>/dev/null
	rm -f $PidPath/*.pid 2>/dev/null
	echo " "
	if [ -f $ServerRoot/sbin/lighttpd ]; then
		echo "Service lighttpd used by pxesrv is installed"
		echo "--------------------------------------------" && exit
	fi

	if [ -f $SourceDir/lighttpd*.tar.gz ]; then
		cd $SourceDir && tar zvxf lighttpd*.tar.gz -C $BuildDir && cd $BuildDir/lighttpd*
		./configure --prefix=$ServerRoot --exec-prefix=$ServerRoot --mandir=$ServerRoot/share --libdir=$ServerRoot/lib --sbindir=$ServerRoot/sbin
		make && make install
		echo "Entering directory: $ServerRoot"
		cd $ServerRoot && mkdir -p $LogDir 2>/dev/null
		sleep 1 && rm -rf $BuildDir/lighttpd*
	else
		echo "Sourcearchive (tar.gz) Not installed in $SourceDir/lighttpd"
		echo "-----------------------------------------------------------"
	fi
echo " "
;;

install_all)
echo " "
	echo "Finalizing installation - Start those services using: $0 restart"
	cp -R $SourceDir/conf $ServerRoot
	chown -R $User:$Group $ServerRoot
	chmod -R 775 $ServerRoot
echo " "
;;

*)
	echo "Usage: restart|status|stop|install_dnsmasq|install_lighttpd|install_all"
;;

esac