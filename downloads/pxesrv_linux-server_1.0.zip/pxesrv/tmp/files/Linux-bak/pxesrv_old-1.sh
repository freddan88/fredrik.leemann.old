#!/bin/sh
#
Group=sudo
User=www-data
ServerRoot=/srv/pxesrv
SourceDir=/srv/pxesrv/src
PxeBoot=/srv/pxesrv/pxe-boot
LogDir=/srv/pxesrv/share/log
BuildDir=/srv/pxesrv/src/build
DnsmasqPid=/srv/pxesrv/sbin/dnsmasq.pid
LighttpdPid=/srv/pxesrv/sbin/lighttpd.pid
#################################
##
if [ "$(id -u)" != "0" ]; then
	echo " "
	echo "PLEASE RUN THIS SCRIPT AS ROOT OR SUDO!"
	echo "---------------------------------------" && exit
fi
##
case $1 in

start)
	if [ -f $LighttpdPid ]; then
		echo " "
		echo "Lighttpd is running please stop it to use this command"
		echo "------------------------------------------------------"
	else
		echo " " && echo "Starting Lighttpd - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/lighttpd -f /srv/pxesrv/conf/lighttpd.conf
		ps -e | grep $(cat $LighttpdPid) 2>/dev/null
		echo " " && echo "Starting Dnsmasq - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/dnsmasq -x $DnsmasqPid --conf-file=/srv/pxesrv/conf/dnsmasq.conf
		ps -e | grep $(cat $DnsmasqPid) 2>/dev/null
		echo " "
	fi	
;;

stop)
	if ! [ -f $LighttpdPid ]; then
		echo " "
		echo "Lighttpd is not running please start it to use this command"
		echo "-----------------------------------------------------------"
	else
		echo " " && echo "Stopping Lighttpd" && sleep 1
		kill -9 $(cat $LighttpdPid) 2>/dev/null
		rm -f $LighttpdPid 2>/dev/null
	fi

	if ! [ -f $DnsmasqPid ]; then
		echo " "
		echo "Dnsmasq is not running please start it to use this command"
		echo "-----------------------------------------------------------"
	else
		echo " " && echo "Stopping Dnsmasq" && sleep 1
		kill -9 $(cat $DnsmasqPid) 2>/dev/null
		rm -f $DnsmasqPid 2>/dev/null
		echo "----------------"
	fi
;;

restart|reload)
	$0 stop
	$0 start
;;

install_dnsmasq)
	echo " "
	if [ -f $ServerRoot/sbin/dnsmasq ];then
		echo "Service dnsmasq used by pxesrv is installed"
		echo "-------------------------------------------" && exit
	fi

	if [ -f $SourceDir/dnsmasq*.tar.gz ]; then
		cd $SourceDir && tar zvxf dnsmasq*.tar.gz -C $BuildDir && cd $BuildDir/dnsmasq*
		sed -i 's/usr/srv/g' Makefile
		sed -i 's/local/pxesrv/g' Makefile		
		sed -i 's/pxesrve/locale/g' Makefile
		make && make install
		echo "Entering directory: $ServerRoot" && cd $ServerRoot
		sleep 1 && rm -rf $BuildDir/dnsmasq*
		echo " " && $0 install
	else
		echo "Sourcearchive (tar.gz) Not installed in $SourceDir/dnsmasq"
		echo "----------------------------------------------------------"	
	fi
;;

install_lighttpd)
	echo " "
	if [ -f $ServerRoot/sbin/lighttpd ];then
		echo "Service lighttpd used by pxesrv is installed"
		echo "--------------------------------------------" && exit
	fi

	if [ -f $SourceDir/lighttpd*.tar.gz ]; then
		cd $SourceDir && tar zvxf lighttpd*.tar.gz -C $BuildDir && cd $BuildDir/lighttpd*
		./configure --prefix=$ServerRoot --exec-prefix=$ServerRoot --mandir=$ServerRoot/share --libdir=$ServerRoot/lib --sbindir=$ServerRoot/sbin
		make && make install
		echo "Entering directory: $ServerRoot" && cd $ServerRoot
		sleep 1 && rm -rf $BuildDir/lighttpd*
		echo " " && $0 install
	else
		echo "Sourcearchive (tar.gz) Not installed in $SourceDir/lighttpd"
		echo "-----------------------------------------------------------"
	fi
;;

install)
	mkdir -p $LogDir && mkdir -p $PxeBoot
	cp -R $SourceDir/conf $ServerRoot && chmod -R 775 $ServerRoot
	chmod 777 $LogDir 2>/dev/null && chown -R $User:$Group $ServerRoot
;;

*)
	echo "Usage $0 (start|stop|restart|install_lighttpd|install_dnsmasq)"
;;

esac