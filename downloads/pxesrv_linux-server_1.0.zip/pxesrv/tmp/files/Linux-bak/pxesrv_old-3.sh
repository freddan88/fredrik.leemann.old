#!/bin/sh
# Updated: 2017-09-06
# Script: www.leemann.se/fredrik | www.youtube.com/user/FreLee54
# Dnsmasq: http://www.thekelleys.org.uk/dnsmasq/doc.html 
# Lighttpd: https://www.lighttpd.net
###########
User=pxesrv
Group=pxesrv
ServerRoot=/srv/pxesrv
PxeBoot=/srv/pxesrv/pxe-boot
############################

if [ "$(id -u)" != "0" ]; then
	echo " "
	echo "PLEASE RUN THIS SCRIPT AS ROOT OR SUDO!"
	echo "---------------------------------------"
	exit
fi

##########
case $1 in

start)
echo " "
	if [ -f $ServerRoot/src/pid/pxesrv.lock ]; then
		echo "Services is running"
		echo "-------------------"
	else
		echo "Starting Lighttpd - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/lighttpd -f $ServerRoot/conf/lighttpd.conf
		ps -e | grep $(cat $ServerRoot/src/pid/lighttpd.pid) 2>/dev/null
	echo " "
		echo "Starting Dnsmasq - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ServerRoot/sbin/dnsmasq -x $ServerRoot/src/pid/dnsmasq.pid --conf-file=$ServerRoot/conf/dnsmasq.conf
		ps -e | grep $(cat 2>/dev/null $ServerRoot/src/pid/dnsmasq.pid) 2>/dev/null
		touch $ServerRoot/src/pid/pxesrv.lock
	fi
echo " "
;;

stop)
echo " "
	if ! [ -f $ServerRoot/src/pid/dnsmasq.pid ]; then
		echo "Dnsmasq is not running"
	else
		echo "Stopping Dnsmasq" && sleep 1
		kill -9 $(cat 2>/dev/null $ServerRoot/src/pid/dnsmasq.pid) 2>/dev/null
		rm -f $ServerRoot/src/pid/dnsmasq.pid 2>/dev/null
	fi

	if ! [ -f $ServerRoot/src/pid/lighttpd.pid ]; then
		echo "Lighttpd is not running"
	else
		echo "Stopping Lighttpd" && sleep 1
		kill -9 $(cat 2>/dev/null $ServerRoot/src/pid/lighttpd.pid) 2>/dev/null
		rm -f $ServerRoot/src/pid/lighttpd.pid 2>/dev/null
	fi

	rm -f $ServerRoot/src/pid/pxesrv.lock
echo " "
;;

restart)
echo " "
	echo "Stopping services"
	echo "-----------------"
	$ServerRoot/pxesrv stop >/dev/null
	$ServerRoot/pxesrv start
;;

status)
echo " "
	if ! [ -f $ServerRoot/src/pid/pxesrv.lock ]; then
		echo "Services is not running"
		echo "-----------------------"
	else
		echo "Pidfiles located in: $ServerRoot/src/pid"
		echo " " && echo "Displaying runing processes:"
	echo " "
		echo "  PID TTY          TIME CMD"	
		ps -e | grep $(cat 2>/dev/null $ServerRoot/src/pid/dnsmasq.pid) 2>/dev/null
		ps -e | grep $(cat 2>/dev/null $ServerRoot/src/pid/lighttpd.pid) 2>/dev/null
	fi
echo " "
;;

make_s1)
echo " "
	if [ -f $ServerRoot/sbin/dnsmasq ]; then
		echo "Service dnsmasq used by pxesrv is installed"
		echo "-------------------------------------------" && exit
	fi

	if [ -f $ServerRoot/src/dnsmasq*.tar.gz ]; then
		$ServerRoot/pxesrv stop >/dev/null stop
		tar zxf $ServerRoot/src/dnsmasq*.tar.gz -C $ServerRoot/src/build
		cd $ServerRoot/src/build/dnsmasq*
		sed -i 's/usr/srv/g' Makefile
		sed -i 's/local/pxesrv/g' Makefile		
		sed -i 's/pxesrve/locale/g' Makefile
		make && make install && cd $ServerRoot
		echo "Entering directory: $ServerRoot"
		sleep 1 && rm -rf $ServerRoot/src/build/dnsmasq*
	else
		echo "Sourcearchive (tar.gz) Not installed in $ServerRoot/src/dnsmasq"
		echo "---------------------------------------------------------------"	
	fi
echo " "
;;

make_s2)
echo " "
	if [ -f $ServerRoot/sbin/lighttpd ]; then
		echo "Service lighttpd used by pxesrv is installed"
		echo "--------------------------------------------" && exit
	fi

	if [ -f $ServerRoot/src/lighttpd*.tar.gz ]; then
		$ServerRoot/pxesrv stop >/dev/null
		tar zxf $ServerRoot/src/lighttpd*.tar.gz -C $ServerRoot/src/build
		cd $ServerRoot/src/build/lighttpd*
		./configure --prefix=$ServerRoot --exec-prefix=$ServerRoot --mandir=$ServerRoot/share --libdir=$ServerRoot/lib --sbindir=$ServerRoot/sbin
		make && make install && cd $ServerRoot
		echo "Entering directory: $ServerRoot"
		mkdir -p $ServerRoot/share/log 2>/dev/null
		sleep 1 && rm -rf $ServerRoot/src/build/lighttpd*
	else
		echo "Sourcearchive (tar.gz) Not installed in $ServerRoot/src/lighttpd"
		echo "----------------------------------------------------------------"
	fi
echo " "
;;

finalize)
echo " "
	cd $ServerRoot/src
	echo "Finalizing installation - Start those services using: $0 start"
	useradd -r -U -c "pxesrv" -d $ServerRoot -s /bin/false pxesrv 2>/dev/null

if [ -d $ServerRoot/boot-dir ]; then
	echo "Directory: boot-dir already copied to $ServerRoot"
else
	cp -R $ServerRoot/src/files/boot-dir $ServerRoot
fi

if [ -d $ServerRoot/conf ]; then
	echo "Directory: conf already copied to $ServerRoot"
else
	cp -R $ServerRoot/src/files/conf $ServerRoot
fi

if [ -f $ServerRoot/src/syslinux-4.07.tar.gz ]; then
	echo "syslinux-4.07.tar.gz already downloaded!" && echo " "
else
	wget https://www.kernel.org/pub/linux/utils/boot/syslinux/4.xx/syslinux-4.07.tar.gz
fi

	tar zxf $ServerRoot/src/syslinux-4.07.tar.gz -C $ServerRoot/conf/tftp-boot
	cp $ServerRoot/conf/tftp-boot/syslinux-4.07/gpxe/gpxelinux.0 $ServerRoot/conf/tftp-boot
	
	$ServerRoot/pxesrv perm
	ln -sf $ServerRoot/pxesrv /usr/local/sbin/pxesrv
	cp -f $ServerRoot/src/init.d/init-pxesrv /etc/init.d/init-pxesrv

echo " "
	echo "Script by: www.leemann.se/fredrik"
echo " "
;;

perm)
	chown -R $User:$Group $ServerRoot
	find $ServerRoot -type d -exec chmod 0775 {} \;
	find $ServerRoot -type f -exec chmod 0774 {} \;
	chmod 775 $ServerRoot/pxesrv
;;

remove_all)
echo " "
	if [ -f $ServerRoot/src/pid/pxesrv.lock ]; then
		echo "Services is running"
		echo "-------------------"
		echo " "
		exit
	fi
	
	rm -rf $ServerRoot/lib $ServerRoot/sbin $ServerRoot/share 2>/dev/null
	mv -f $ServerRoot/conf $ServerRoot/conf_old 2>/dev/null
	unlink /usr/local/sbin/pxesrv 2>/dev/null
	
	chkconfig init-pxesrv off 2>/dev/null
	chkconfig --del init-pxesrv 2>/dev/null
	update-rc.d -f httpsrv remove 2>/dev/null
	rm -f /etc/init.d/init-pxesrv 2>/dev/null
	sleep 1 && echo "Uninstallation completed!"
echo " "
;;

*)
	echo " "
	echo "Usage: pxesrv start|stop|perm|restart|status|make_s1|make_s2|finalize|remove_all"
	echo "--------------------------------------------------------------------------------"
;;

esac