﻿Author: Fredrik Leemann

Links:
------
WebPage: http://www.leemann.se/fredrik
Donate: https://www.paypal.me/freddan88
YouTube: https://www.youtube.com/user/FreLee54
GitHub: https://github.com/freddan88

Description:
------------
Sourcefile (example map) can be opened with Valve Hammer Editor

I take no responsibility for this script, use at your own risk

-----------------------------------------------------------------------------