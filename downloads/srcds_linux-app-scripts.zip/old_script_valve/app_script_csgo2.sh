#! /bin/sh
#
# Version: 2.0 - 2014-03-04
# Scripted by: Fps_sWe|Fredd|SDK/VHE - www.leemann.se/fredrik
# Script to start, debug, stop, restart, install and update Counter-Strike Global Offensive Dedicated Servers.
# Debug will start the server in terminal and log to console.log. Debug will also default the server to lanmode. 
# Start will start the server in a new screensession with the name of the "screen parameter".
# "sudo apt-get install screen" in a new terminal will install screen if you are using Debian/Ubuntu
#
#### Use lowercase letters because some games can bug when using large ex: csgo	
#### Installation - configuration:
folder=csgo1 # Installationfolder for Counter-Strike Global Offensive Dedicated Server.
screen=csgo1 # Screen name for Counter-Strike Global Offensive Dedicated Server

#### Gameserver - configuration:
port=27016
ip=0.0.0.0

#### Gamemodes:
casual="+game_type 0 +game_mode 0 +mapgroup mg_bomb +map de_dust" # Gamemode: Classic Casual
competitive="+game_type 0 +game_mode 1 +mapgroup mg_bomb_se +map de_dust2_se" # Gamemode: Classic Competitive
arms_race="+game_type 1 +game_mode 0 +mapgroup mg_armsrace +map ar_shoots" # Gamemode: Arms Race
demolition="+game_type 1 +game_mode 1 +mapgroup mg_demolition +map de_lake" # Gamemode: Demolition
deathmatch="+game_type 1 +game_mode 2 +mapgroup mg_allclassic +map de_dust" # Gamemode: Deathmatch

#### Active gamemode:
mode=$casual

#### Don´t edit below: 
case "$1" in

start)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?
Please use: ($0 stop) before using this command"
else
touch $folder/lock
echo "Starting SRCDS for Counter-Strike Global Offensive:
Type screen -x $screen to view console, press CTRL+A+D togheter to detatch" && sleep 0.5
cd $folder && servercommands="-game csgo -console -usercon $mode +ip $ip -port $port"
screen -A -m -d -S $screen ./srcds_run $servercommands
screen -list
fi
;;

debug)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?
Please use: ($0 stop) before using this command"
else
echo "Starting SRCDS for Counter-Strike Global Offensive in debugmode" && cd $folder
echo "Se outputfile: console.log in $folder/csgo/console.log" && sleep 2
./srcds_run -game csgo -console -usercon $mode +ip $ip -port $port +sv_lan 1 -debug -condebug
fi
;;

stop)
rm $folder/lock 2> /dev/null
echo "Stopping Counter-Strike Global Offensive server ($screen)" && sleep 0.5
screen -S $screen -X quit
screen -list
;;

restart|reload)
$0 stop
sleep 0.5
$0 start
;;

update)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?
Please use: ($0 stop) before using this command"
else
echo "Updating Counter-Strike Global Offensive Dedicated server in ./$folder" && sleep 1
cd steamcmd && ./steamcmd.sh +login anonymous +force_install_dir ../$folder +app_update 740 +quit
echo "Since 15 of February 2014 you might need to create a new text document:
steam_appid.txt Create it in ./$folder and paste "730" in, without quotes...
Update complete, you can now start the server using $0 start"
fi
;;

install)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?
Please use: ($0 stop) before using this command"
else
echo "
Please see the links if those commands fail or if you fail to start the server

You will need to install the program: screen, in order to start the server
sudo apt-get install screen will install this program under Debian/Ubuntu

Steamcmd will now be downloaded and installed to ./steamcmd
Counter-Strike Global Offensive Dedicated Server will be installed to ./$folder"
sleep 2
$0 install_mkdir
fi
;;

install_mkdir)
if [ ! -d steamcmd ] ; then 
mkdir ./steamcmd
$0 install_untar
else
$0 install_untar
fi
;;

install_untar)
if [ ! -f steamcmd_linux.tar.gz ] ; then
wget http://media.steampowered.com/installer/steamcmd_linux.tar.gz
tar -xvzf steamcmd_linux.tar.gz -C steamcmd
$0 install_appid
else
tar -xvzf steamcmd_linux.tar.gz -C steamcmd
$0 install_appid
fi
;;

install_appid)
cd steamcmd
./steamcmd.sh +login anonymous +force_install_dir ../$folder +app_update 740 validate +quit
sleep 0.5
echo "
####################################################################
Installation instructions can be found here:
https://developer.valvesoftware.com/wiki/SteamCMD#Running_SteamCMD

List of available app_id´s (Linux Dedicated Servers):
https://developer.valvesoftware.com/wiki/Dedicated_Servers_List
#####################################################################"
echo "
You will need to install the program: screen, in order to start the server
sudo apt-get install screen will install this program under Debian/Ubuntu

Update complete, you can now start the server using $0 start
Please see the links if those commands failed or if the server refuse to start

Since 15 of February 2014 you might need to create a new text document:
steam_appid.txt Create it in ./$folder and paste "730" in, without quotes...

Install manualy: cd to the folder steamcmd and run the command ./steamcmd.sh"
;;

*)
echo "Usage: $0 {start|stop|restart/reload|debug|install|update}"
;;

esac
exit 0
