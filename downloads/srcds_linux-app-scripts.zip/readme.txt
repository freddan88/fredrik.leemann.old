Author: Fredrik Leemann

Links:
------
WebPage: http://www.leemann.se/fredrik
Donate: https://www.paypal.me/freddan88
YouTube: https://www.youtube.com/user/FreLee54
GitHub: https://github.com/freddan88

Description:
------------
Manage SRCDS CSS/CSGO install/Update/Start/Stop/Restart

I take no responsibility for this script, use at your own risk

-----------------------------------------------------------------------------

Those script require that you have screen installed.

Under Debian/Ubuntu you can install this package by typing "sudo apt-get install screen"
If you are using a 64bit operating system you may need to install 32bit libraries.

Read this link for more information: 
https://developer.valvesoftware.com/wiki/SteamCMD#32-bit_libraries_on_64-bit_Linux_systems

Are you using Cent OS and can´t login via steamcmd, se this link:
https://developer.valvesoftware.com/wiki/SteamCMD#Login_Failure:_No_Connection

CONFIGURATION:

Se the configuration section on appropriate script.

Counter-Strike Source:
folder=css1 # Installationfolder for Counter-Strike Source Dedicated Server.
screen=css1 # Screen name for Counter-Strike Source Dedicated Server
players=10
port=27015
map=de_dust2
ip="Your computers ip address" ex. 192.168.0.10

Counter-Strike Global Offensive:
folder=csgo1 # Installationfolder for Counter-Strike Global Offensive Dedicated Server.
screen=csgo1 # Screen name for Counter-Strike Global Offensive Dedicated Server
port=27015
ip="Your computers ip address" ex. 192.168.0.10
#### Gamemodes:
Classic Casual - Default
Classic Competitive - Default
Arms Race - Default
Demolition - Default
Deathmatch - Default
You can also add custom ones here
#### Active gamemode:
mode=$casual - Default
Change this if you develop your own gamemod

You can restore backups by uploading your compressed archive to the folder were you game-folder is,
for Counter-Strike Source your gamefolder is "cstrike" Untar the file using this command:
tar -zxvf cstrike_backup_*.tar.gz