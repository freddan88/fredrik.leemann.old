#! /bin/sh
# Version: 3.0 - 2015-02-08
# Scripted by: Fps_sWe|Fredd|SDK/VHE / Fps_sWe|F3L - www.leemann.se/fredrik
# Script to manage Counter-Strike Source Dedicated Servers.
# Installation instructions can be found here:
# https://developer.valvesoftware.com/wiki/SteamCMD#Running_SteamCMD
# List of available app_id´s (Linux Dedicated Servers):
# https://developer.valvesoftware.com/wiki/Dedicated_Servers_List
# Debug will start the server in terminal and log to console.log
# Debug will also default the server to lanmode. 
# Start will start the server in a new screensession with the name of the "screen-parameter".
# Use lowercase letters because some games can bug when using large ex: csgo

#### Installation - configuration:
# "folder" = Installationfolder for Counter-Strike Source Dedicated Server
# "steam" = Installationfolder for SRCDS updatetool (steamcmd)
# "screen" = Screen name for gameserver
# "filename" = Filename for backups
folder=/tmp/srcds/css1
steam=/tmp/srcds/steamcmd
screen=css1
filename=cstrike_backup_$(date +"%Y%m%d").tar.gz

#### Gameserver - configuration:
players=12
port=27015
map=de_dust2
ip=0.0.0.0

#### Don´t edit below: 
case "$1" in

start)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
touch $folder/lock
echo "Starting SRCDS for Counter-Strike Source:
Type screen -x $screen to view console, press CTRL+A+D togheter to detatch" && sleep 0.5
servercommands="-game cstrike +map $map +maxplayers $players +ip $ip -port $port -steamport $port"
screen -A -m -d -S $screen $folder/srcds_run $servercommands
screen -list
fi
;;

debug)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
echo "Starting SRCDS for Counter-Strike Source in debugmode"
echo "Debuging to console.log in $folder/cstrike/console.log" && sleep 2
$folder/srcds_run -game cstrike +map $map +maxplayers $players +ip $ip -port $port +sv_lan 1 -debug -condebug
fi
;;

stop)
rm $folder/lock 2> /dev/null
echo "Stopping Counter-Strike Source server ($screen)" && sleep 0.5
screen -S $screen -X quit
screen -list
;;

restart|reload)
$0 stop
sleep 0.5
$0 start
;;

backup)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
dest_dir=$folder/backup
backup_dir=$folder/cstrike
mkdir -p $folder/backup/cstrike/cfg $folder/backup/cstrike/maps
echo "Now creating: $dest_dir/$filename"
cd $backup_dir
cp maps/*.nav $dest_dir/cstrike/maps 2>/dev/null
cp -R addons custom doc materials models tools sound mapcycle.txt motd* $dest_dir/cstrike 2>/dev/null
cd $backup_dir/cfg
cp -R sourcemod xa server.cfg autoexec.cfg banned_ip.cfg banned_user.cfg gungame* $dest_dir/cstrike/cfg 2>/dev/null
cd $dest_dir
tar -pczf $filename cstrike
rm -rf cstrike
echo "Done creating backup. Untar this file using: tar -zxvf $filename"
fi
;;

update)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
echo "Updating CSS Dedicated server in $folder" && sleep 1
$steam/steamcmd.sh +login anonymous +force_install_dir $folder +app_update 232330 +quit
echo "Update complete, you can now start the server using $0 start"
fi
;;

install)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
echo "Updatetool (Steamcmd) will be downloaded and installed to $steam"
echo "Gameserver (SRCDS) will be downloaded and installed to $folder"
sleep 2
$0 install1
fi
;;

install1)
if [ ! -d $steam ] ; then 
mkdir -p $steam
$0 install2
else
$0 install2
fi
;;

install2)
cd $steam
if [ ! -f steamcmd_linux.tar.gz ] ; then
wget http://media.steampowered.com/installer/steamcmd_linux.tar.gz
tar -xvzf steamcmd_linux.tar.gz
./steamcmd.sh +login anonymous +force_install_dir $folder +app_update 232330 validate +quit
echo "Installation complete, you can now start the server using $0 start"
else
./steamcmd.sh +login anonymous +force_install_dir $folder +app_update 232330 validate +quit
echo "Installation complete, you can now start the server using $0 start"
fi
;;

*)
echo "Usage: $0 {start|stop|restart/reload|debug|backup|install|update}"
;;

esac
exit 0
