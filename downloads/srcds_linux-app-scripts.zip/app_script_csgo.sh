#! /bin/sh
# Version: 3.5 - 2015-11-20
# Scripted by: Fps_sWe|Fredd|SDK/VHE / Fps_sWe|F3L - www.leemann.se/fredrik
# Script to manage Counter-Strike Global Offeensive Dedicated Servers.
# Installation instructions can be found here:
# https://developer.valvesoftware.com/wiki/SteamCMD#Running_SteamCMD
# List of available app_id´s (Linux Dedicated Servers):
# https://developer.valvesoftware.com/wiki/Dedicated_Servers_List
# Debug will start the server in terminal and log to console.log
# Debug will also default the server to lanmode. 
# Start will start the server in a new screensession with the name of the "screen-parameter".
# Use lowercase letters because some games can bug when using large ex: csgo
# Since 15 of February 2014 you might need to create a new text document:
# steam_appid.txt Create it in ./$folder and paste "730" in, without quotes...

#### Installation - configuration:
# "folder" = Installationfolder for Counter-Strike Global Offensive Dedicated Server
# "steam" = Installationfolder for SRCDS updatetool (steamcmd)
# "screen" = Screen name for gameserver
folder=/home/srcds/csgo1
steam=/home/srcds/steamcmd
screen=csgo1

#### Gameserver - configuration:
port=27019
ip=192.168.224.19

#### Gamemodes:
casual="./srcds_run -game csgo -console -usercon -port $port +ip $ip +game_type 0 +game_mode 0 +mapgroup mg_active +map de_dust2" 			#Gamemode: Classic Casual

competitive="./srcds_run -game csgo -console -usercon -port $port +ip $ip +game_type 0 +game_mode 1 +mapgroup mg_active +map de_dust2 "		#Gamemode: Classic Competitive

arms_race="./srcds_run -game csgo -console -usercon -port $port +ip $ip +game_type 1 +game_mode 0 +mapgroup mg_armsrace +map ar_shoots"		#Gamemode: Arms Race

demolition="./srcds_run -game csgo -console -usercon -port $port +ip $ip +game_type 1 +game_mode 1 +mapgroup mg_demolition +map de_lake"	#Gamemode: Demolition

deathmatch="./srcds_run -game csgo -console -usercon -port $port +ip $ip +game_type 1 +game_mode 2 +mapgroup mg_allclassic +map de_dust"	#Gamemode: Deathmatch

#### Active gamemode:
start_mode=$casual

#### Don´t edit below: 
case "$1" in

start)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
touch $folder/lock
echo "Starting SRCDS for Counter-Strike Global Offensive:
Type screen -x $screen to view console, press CTRL+A+D togheter to detatch" && sleep 0.5
cd $folder && screen -A -m -d -S $screen $start_mode
sleep 0.5 && screen -list
fi
;;

debug)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?
Please use: ($0 stop) before using this command"
else
echo "Starting SRCDS for Counter-Strike Global Offensive in debugmode"
echo "Debuging to console.log in $folder/csgo/console.log" && sleep 2
cd $folder && $start_mode +sv_lan 1 -debug -condebug
fi
;;

stop)
rm $folder/lock 2> /dev/null
echo "Stopping Counter-Strike Global Offensive server ($screen)" && sleep 0.5
screen -S $screen -X quit
screen -list
;;

restart|reload)
$0 stop
sleep 0.5
$0 start
;;

update)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
echo "Updating CSGO Dedicated server in $folder" && sleep 1
$steam/steamcmd.sh +login anonymous +force_install_dir $folder +app_update 740 +quit
echo "Update complete, you can now start the server using $0 start"
fi
;;

install)
if [ -f $folder/lock ] ; then
echo "lockfile exist, is srcds runnig ?"
echo "Please use: ($0 stop) before using this command"
else
echo "Updatetool (Steamcmd) will be downloaded and installed to $steam"
echo "Gameserver (SRCDS) will be downloaded and installed to $folder"
sleep 2
$0 install1
fi
;;

install1)
if [ ! -d $steam ] ; then 
mkdir -p $steam
$0 install2
else
$0 install2
fi
;;

install2)
cd $steam
if [ ! -f steamcmd_linux.tar.gz ] ; then
wget http://media.steampowered.com/installer/steamcmd_linux.tar.gz
tar -xvzf steamcmd_linux.tar.gz
./steamcmd.sh +login anonymous +force_install_dir $folder +app_update 740 validate +quit
echo "Installation complete, you can now start the server using $0 start"
else
./steamcmd.sh +login anonymous +force_install_dir $folder +app_update 740 validate +quit
echo "Installation complete, you can now start the server using $0 start"
fi
;;

*)
echo "Usage: $0 {start|stop|restart/reload|debug|install|update}"
;;

esac
exit 0
