
GParted Live on PXE Server

Link:
http://gparted.org/livepxe.php