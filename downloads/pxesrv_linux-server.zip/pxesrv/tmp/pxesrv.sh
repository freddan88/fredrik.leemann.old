#!/bin/sh
# Updated: 2017-09-24
# Script: www.leemann.se/fredrik | www.youtube.com/user/FreLee54
# Dnsmasq: http://www.thekelleys.org.uk/dnsmasq/doc.html 
# Lighttpd: https://www.lighttpd.net
#################
## Configuration:
User=pxesrv
Group=pxesrv
S1_SRC=http://www.thekelleys.org.uk/dnsmasq/dnsmasq-2.77.tar.gz
S2_SRC=https://download.lighttpd.net/lighttpd/releases-1.4.x/lighttpd-1.4.45.tar.gz
###################################################################################
ROOT=/srv/pxesrv
################
if [ "$(id -u)" != "0" ]; then
	echo " "
	echo "PLEASE RUN THIS SCRIPT AS ROOT OR SUDO!"
	echo "---------------------------------------"
	exit
fi
##########
case $1 in

start)
echo " "
	if [ -f $ROOT/tmp/pid/pxesrv.lock ]; then
		echo "Services is running"
		echo "-------------------"
	else
		echo "Starting Lighttpd - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ROOT/sbin/lighttpd -f $ROOT/conf/lighttpd.conf
		ps -e | grep $(cat $ROOT/tmp/pid/lighttpd.pid) 2>/dev/null
	echo " "
		echo "Starting Dnsmasq - Service for pxesrv" && sleep 1
		echo " " && echo "  PID TTY          TIME CMD"
		$ROOT/sbin/dnsmasq -x $ROOT/tmp/pid/dnsmasq.pid --conf-file=$ROOT/conf/dnsmasq.conf
		ps -e | grep $(cat 2>/dev/null $ROOT/tmp/pid/dnsmasq.pid) 2>/dev/null
		touch $ROOT/tmp/pid/pxesrv.lock
	fi
echo " "
;;

stop)
echo " "
	if ! [ -f $ROOT/tmp/pid/dnsmasq.pid ]; then
		echo "Dnsmasq is not running"
	else
		echo "Stopping Dnsmasq" && sleep 1
		kill -9 $(cat 2>/dev/null $ROOT/tmp/pid/dnsmasq.pid) 2>/dev/null
		rm -f $ROOT/tmp/pid/dnsmasq.pid 2>/dev/null
	fi

	if ! [ -f $ROOT/tmp/pid/lighttpd.pid ]; then
		echo "Lighttpd is not running"
	else
		echo "Stopping Lighttpd" && sleep 1
		kill -9 $(cat 2>/dev/null $ROOT/tmp/pid/lighttpd.pid) 2>/dev/null
		rm -f $ROOT/tmp/pid/lighttpd.pid 2>/dev/null
	fi

	rm -f $ROOT/tmp/pid/pxesrv.lock
echo " "
;;

restart)
echo " "
	echo "Stopping services"
	echo "-----------------"
	$ROOT/tmp/pxesrv.sh stop >/dev/null
	$ROOT/tmp/pxesrv.sh start
;;

status)
echo " "
	if ! [ -f $ROOT/tmp/pid/pxesrv.lock ]; then
		echo "Services is not running"
		echo "-----------------------"
	else
		echo "Pidfiles located in: $ROOT/tmp/pid"
		echo " " && echo "Displaying runing processes:"
	echo " "
		echo "  PID TTY          TIME CMD"	
		ps -e | grep $(cat 2>/dev/null $ROOT/tmp/pid/dnsmasq.pid) 2>/dev/null
		ps -e | grep $(cat 2>/dev/null $ROOT/tmp/pid/lighttpd.pid) 2>/dev/null
	fi
echo " "
;;

perm)
	chown -R $User:$Group $ROOT
	find $ROOT -type d -exec chmod 0775 {} \;
	find $ROOT -type f -exec chmod 0764 {} \;
	chmod 774 $ROOT/tmp/pxesrv.sh
;;

make_s1)
echo " "
mkdir -p $ROOT/tmp/src/build
$ROOT/tmp/pxesrv.sh stop >/dev/null
	if [ -f $ROOT/sbin/dnsmasq ]; then
		echo "Service dnsmasq used by pxesrv is installed"
		echo "-------------------------------------------" && exit
	fi
	
	if ! [ -f $ROOT/tmp/src/dnsmasq.tar.gz ]; then
		cd $ROOT/tmp/src && wget -O dnsmasq.tar.gz $S1_SRC 2>/dev/null
	fi
		cd $ROOT/tmp/src && tar -zxf dnsmasq.tar.gz -C $ROOT/tmp/src/build 2>/dev/null
		cd $ROOT/tmp/src/build/dnsmasq*
		sed -i 's/usr/srv/g' Makefile
		sed -i 's/local/pxesrv/g' Makefile		
		sed -i 's/pxesrve/locale/g' Makefile
		make && make install && cd $ROOT
		rm -rf $ROOT/tmp/src/build
	echo " "
	echo "Dnsmasq compiled and installed"
	echo "------------------------------"
;;

make_s2)
echo " "
mkdir -p $ROOT/tmp/src/build
$ROOT/tmp/pxesrv.sh stop >/dev/null
	if [ -f $ROOT/sbin/lighttpd ]; then
		echo "Service lighttpd used by pxesrv is installed"
		echo "--------------------------------------------" && exit
	fi
	
	if ! [ -f $ROOT/tmp/src/lighttpd.tar.gz ]; then
		cd $ROOT/tmp/src && wget -O lighttpd.tar.gz $S2_SRC 2>/dev/null
	fi
		cd $ROOT/tmp/src && tar -zxf lighttpd.tar.gz -C $ROOT/tmp/src/build 2>/dev/null
		cd $ROOT/tmp/src/build/lighttpd*
		./configure --prefix=$ROOT --exec-prefix=$ROOT --mandir=$ROOT/share --libdir=$ROOT/lib --sbindir=$ROOT/sbin
		make && make install && cd $ROOT
		mkdir -p $ROOT/share/log
		rm -rf $ROOT/tmp/src/build
	echo " "
	echo "Lighttpd compiled and installed"
	echo "-------------------------------"
;;

finalize)
echo " "
	cd $ROOT/tmp/src
	mkdir -p $ROOT/tmp/pid
	echo "Finalizing installation"
	useradd -r -U -c "pxesrv" -d $ROOT -s /bin/false pxesrv 2>/dev/null

if [ -d $ROOT/boot-dir ]; then
	echo "Directory: boot-dir already copied to $ROOT"
else
	cp -R $ROOT/tmp/files/boot-dir $ROOT
fi

if [ -d $ROOT/conf ]; then
	echo "Directory: conf already copied to $ROOT"
else
	cp -R $ROOT/tmp/files/conf $ROOT
fi

if [ -f $ROOT/tmp/src/syslinux-4.07.tar.gz ]; then
	echo "syslinux-4.07.tar.gz already downloaded!" && echo " "
else
	wget https://www.kernel.org/pub/linux/utils/boot/syslinux/4.xx/syslinux-4.07.tar.gz
fi
	tar -zxf $ROOT/tmp/src/syslinux-4.07.tar.gz -C $ROOT/conf/tftp-boot
	cp $ROOT/conf/tftp-boot/syslinux-4.07/gpxe/gpxelinux.0 $ROOT/conf/tftp-boot
	
	$ROOT/tmp/pxesrv.sh perm
	ln -sf $ROOT/tmp/pxesrv.sh /usr/local/sbin/pxesrv
	cp -f $ROOT/tmp/init-pxesrv.sh /etc/init.d/init-pxesrv
	chmod 764 /etc/init.d/init-pxesrv 2>/dev/null
	
echo " "
	echo "Script by: www.leemann.se/fredrik"
echo " "
;;

remove_all)
echo " "
	if [ -f $ROOT/tmp/pid/pxesrv.lock ]; then
		echo "Services is running"
		echo "-------------------"
		echo " "
		exit
	fi

	rm -rf ${ROOT}_bakup 2>/dev/null
	unlink /usr/local/sbin/pxesrv 2>/dev/null
	mkdir -p ${ROOT}_bakup
	
	mv -f $ROOT/conf ${ROOT}_bakup/conf 2>/dev/null
	mv -f $ROOT/boot-dir ${ROOT}_bakup/boot-dir 2>/dev/null
	
	userdel -fr pxesrv 2>/dev/null
	chkconfig --del init-pxesrv 2>/dev/null
	update-rc.d -f init-pxesrv remove 2>/dev/null
	echo "Created pxesrv_backup in /srv"
	
	chkconfig init-pxesrv off 2>/dev/null
	rm -f /etc/init.d/init-pxesrv 2>/dev/null
	echo " " && echo "Uninstallation completed!"
echo " "
;;

*)
	echo " "
	echo "Arguments: start|stop|restart|status|perm|make_s1|make_s2|finalize|remove_all"
	echo "-----------------------------------------------------------------------------"
;;

esac